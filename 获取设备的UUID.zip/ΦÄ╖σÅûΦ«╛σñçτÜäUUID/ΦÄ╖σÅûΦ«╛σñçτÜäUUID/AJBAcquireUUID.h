//
//  AJBAcquireUUID.h
//  CloudCheckingIn
//
//  Created by CuiJianZhou on 15/11/16.
//  Copyright © 2015年 AnJuBao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AJBAcquireUUID : NSObject


//存
+ (void)save:(NSString *)service data:(id)data;

//取
+ (id)load:(NSString *)service;

@end

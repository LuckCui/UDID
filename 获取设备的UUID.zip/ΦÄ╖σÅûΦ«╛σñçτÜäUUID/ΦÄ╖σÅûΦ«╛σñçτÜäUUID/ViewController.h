//
//  ViewController.h
//  获取设备的UUID
//
//  Created by CuiJianZhou on 15/11/17.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


//
//  main.m
//  获取设备的UUID
//
//  Created by CuiJianZhou on 15/11/17.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

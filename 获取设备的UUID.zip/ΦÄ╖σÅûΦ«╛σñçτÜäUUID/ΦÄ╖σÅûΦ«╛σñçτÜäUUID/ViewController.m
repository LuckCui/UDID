//
//  ViewController.m
//  获取设备的UUID
//
//  Created by CuiJianZhou on 15/11/17.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import "ViewController.h"
#import "AJBAcquireUUID.h"

NSString * const KEY_PASSWORD = @"UUID";
NSString * const KEY_USERUUID = @"USERUUID";


@interface ViewController ()

@property (nonatomic, strong) NSString *UUID;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //拿到设备的UUID
    NSString *identifierStr = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    NSMutableDictionary *usernamepasswordKVPairs = [NSMutableDictionary dictionary];
    [usernamepasswordKVPairs setObject:identifierStr forKey:KEY_PASSWORD];
    
    //存储设备的UUID
    [AJBAcquireUUID save:KEY_USERUUID data:usernamepasswordKVPairs];
    
    //从钥匙串拿出UUID
    self.UUID = [(NSMutableDictionary *)[AJBAcquireUUID load:KEY_USERUUID]objectForKey:KEY_PASSWORD];
}


@end
